<?php
$koneksi = mysqli_connect("localhost", "root","", "upload_db");
?>