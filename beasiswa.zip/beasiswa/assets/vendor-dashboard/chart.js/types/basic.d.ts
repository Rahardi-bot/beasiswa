
export type AnyObject = Record<string, unknown>;
export type EmptyObject = Record<string, never>;
